package servlet;

import dao.LivroDAO;
import model.Livro;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/livros")
public class LivroServlet extends HttpServlet {

    private LivroDAO dao = new LivroDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String acao = req.getParameter("acao");
        if (acao == null) acao = "listar";

        try {
            switch (acao) {
                case "novo":
                    req.getRequestDispatcher("/formulario.jsp").forward(req, resp);
                    break;
                case "editar":
                    int id = Integer.parseInt(req.getParameter("id"));
                    Livro l = dao.buscarPorId(id);
                    req.setAttribute("livro", l);
                    req.getRequestDispatcher("/formulario.jsp").forward(req, resp);
                    break;
                case "remover":
                    int idRem = Integer.parseInt(req.getParameter("id"));
                    dao.remover(idRem);
                    resp.sendRedirect(req.getContextPath() + "/livros");
                    break;
                case "buscar":
                    req.getRequestDispatcher("/buscar.jsp").forward(req, resp);
                    break;
                default:
                    List<Livro> lista = dao.listarTodos();
                    req.setAttribute("lista", lista);
                    req.getRequestDispatcher("/listar.jsp").forward(req, resp);
                    break;
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String acao = req.getParameter("acao");
        if (acao == null) acao = "salvar";

        try {
            switch (acao) {
                case "salvar":
                    Livro l = new Livro();
                    String idStr = req.getParameter("id");
                    if (idStr != null && !idStr.isEmpty()) {
                        l.setId(Integer.parseInt(idStr));
                    }

                    l.setTitulo(req.getParameter("titulo"));
                    l.setAutor(req.getParameter("autor"));
                    String anoStr = req.getParameter("ano");
                    if (anoStr != null && !anoStr.isEmpty()) {
                        try { l.setAno(Integer.parseInt(anoStr)); } catch (NumberFormatException ex) { l.setAno(null); }
                    }
                    l.setGenero(req.getParameter("genero"));
                    l.setDetalhes(req.getParameter("detalhes"));

                    if (l.getId() > 0) {
                        dao.atualizar(l);
                    } else {
                        dao.inserir(l);
                    }
                    resp.sendRedirect(req.getContextPath() + "/livros");
                    break;

                case "buscar":
                    String termo = req.getParameter("termo");
                    if (termo == null) termo = "";
                    List<Livro> resultado = dao.buscarPorTermo(termo);
                    req.setAttribute("resultado", resultado);
                    req.setAttribute("termo", termo);
                    req.getRequestDispatcher("/resultadoBusca.jsp").forward(req, resp);
                    break;
                default:
                    resp.sendRedirect(req.getContextPath() + "/livros");
                    break;
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }
}
